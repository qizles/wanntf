from WeightAgnosticNetwork import CustomModel
from MLPModel import MLP
import tensorflow as tf
import gym
import numpy as np

from gym_cartpole_swingup.envs import CartPoleSwingUpEnv
from copy import deepcopy
from tensorboard import main as tb


BIAS_VALUE = 1
SHARED_WEIGHTS = {-2, -1.5, -1, -0.5, 0.5, 1, 1.5, 2}
SHARED_WEIGHTS = {-2, -1, -0.5, 0.5, 1, 2}



# EVOLUTION_NAMES = {'add': 'addConnection', 'insert': 'insertNode', 'change': 'changeActivation'}
EVOLUTION_NAMES = {'add': MLP.addConnection, 'insert': MLP.insertNode, 'change': MLP.changeActivation}


class ModelWrapper:
    def __init__(self):
        self.tf_model = None
        self.model_plan = None
        self.max_reward = 0
        self.average_reward = 0
        self.best_weight = 1

    def updateTFmodel(self):
        self.tf_model = CustomModel(self.model_plan, -1)

    def evolveModel(self, method):
        # method_name = EVOLUTION_NAMES[method]
        # func = getattr(self, method_name, lambda: 'Invalid')
        func = EVOLUTION_NAMES[method]
        func(self.model_plan)
        self.updateTFmodel()




    @property
    def modelMetrik(self):
        return self.max_reward + self.average_reward




def createModels(n_models, n_inputs, n_outputs):
    models = []
    for _ in range(n_models):
        wrapper = ModelWrapper()
        wrapper.model_plan = MLP(n_inputs, n_outputs)
        wrapper.updateTFmodel()

        models.append(wrapper)
    return models


def eveluateModel(env, modelwrapper):

    VERSION = 1
    max_reward = -1000
    combined_reward = 0
    for weight in SHARED_WEIGHTS:
        modelwrapper.tf_model.changeSharedWeight(weight)
        last_reward = 0
        observation = env.reset()
        for i in range(1000):
            has_been_plus = False
            new_observation = np.append(observation, BIAS_VALUE)
            model_output = modelwrapper.tf_model(new_observation)

            if len(model_output) > 1:
                observation, reward, done, info = env.step(np.argmax(model_output))
            else:
                observation, reward, done, info = env.step(model_output[0].numpy())
                # reward += 1
                #if reward < 0 and not has_been_plus:
                #    reward = 0
                #else:
                #    has_been_plus = True
            last_reward += reward

            if done:
                last_reward -= 1000 - i
                break
            # env.render()

        # max_reward = last_reward if (last_reward > max_reward) else max_reward
        if last_reward > max_reward:
            max_reward = last_reward
            modelwrapper.best_weight = weight
        # if last_reward < 0:
         #   last_reward = 1

        # print(last_reward)

        combined_reward += last_reward
    modelwrapper.max_reward = max_reward
    modelwrapper.average_reward = combined_reward / len(SHARED_WEIGHTS)

    print("scores")
    print(modelwrapper.max_reward)
    print(modelwrapper.average_reward)



    print("")


def rankModels(env, model_wrapper_list, n_winner_elems):
    for model_wrapper in model_wrapper_list:
        eveluateModel(env, model_wrapper)

    model_wrapper_list.sort(key=lambda elem: elem.modelMetrik, reverse=True)
    if n_winner_elems < len(model_wrapper_list):
        model_wrapper_list = model_wrapper_list[0:n_winner_elems]
    return model_wrapper_list


def modelEvolution(model_wrapper_list, n_evolutions=5):
    print("list length {} at model evolution intern".format(len(model_wrapper_list)))
    mutated_list = []

    for mw in model_wrapper_list:
        print(mw.model_plan)
        for i in range(n_evolutions):
            print("evolve step {}".format(i))
            added = ModelWrapper()
            added.model_plan = deepcopy(mw.model_plan)
            added.evolveModel('add')
            added.updateTFmodel()
            mutated_list.append(added)

            inserted = ModelWrapper()
            inserted.model_plan = deepcopy(mw.model_plan)
            inserted.evolveModel('insert')
            inserted.updateTFmodel()
            mutated_list.append(inserted)

            changed = ModelWrapper()
            changed.model_plan = deepcopy(mw.model_plan)
            changed.evolveModel('change')
            changed.updateTFmodel()
            mutated_list.append(changed)

    return model_wrapper_list + mutated_list


def startEvolution(env, models_wrapper_list, n_evolution_steps=10, n_winner_elems=5, n_evolutions=5):
    print("initial length {}".format(len(models_wrapper_list)))

    for i in range(n_evolution_steps-1):
        print("")
        print("rank models")
        print("")
        models_wrapper_list = rankModels(env, models_wrapper_list, n_winner_elems)
        print("list length {} at {} after rank".format(len(models_wrapper_list), i))


        winner = models_wrapper_list[0]
        winner.tf_model.changeSharedWeight(winner.best_weight)
        showWinner(env, winner.tf_model)
        print("")
        print("model evolution")
        print("")
        models_wrapper_list = modelEvolution(models_wrapper_list, n_evolutions)
        print("list length {} at {} after evolution".format(len(models_wrapper_list), i))



    print("")
    print("last ranking")
    print("")
    models_wrapper_list = rankModels(env, models_wrapper_list, n_winner_elems)

    return models_wrapper_list


def showWinner(env, model):
    observation = env.reset()
    for _ in range(1000):
        new_observation = np.append(observation, BIAS_VALUE)
        model_output = model(new_observation)

        observation, reward, done, info = env.step(np.argmax(model_output))
        env.render()

        if done:
            break




if __name__ == '__main__':
    N_INITAL_MODELS = 10
    N_EVOLUTION_STEPS = 15
    N_WINNER = 5
    N_EVOLUTIONS_PER_STEP = 1



    tf.keras.backend.set_floatx('float64')



    # m_env = gym.make('CartPole-v0')
    m_env = CartPoleSwingUpEnv()
    #print(m_env.action_space.shape[0])

    wrapped_models_list = createModels(N_INITAL_MODELS, len(m_env.observation_space.high), m_env.action_space.shape[0])
    wrapped_models_list = startEvolution(m_env, wrapped_models_list, N_EVOLUTION_STEPS, N_WINNER, N_EVOLUTIONS_PER_STEP)
    print("WINNER NETWORK")

    winner = wrapped_models_list[0]

    print(winner.model_plan)
    winner.tf_model.changeSharedWeight(winner.best_weight)
    input()
    showWinner(m_env, winner.tf_model)

    m_env.close()
    print("fin")







